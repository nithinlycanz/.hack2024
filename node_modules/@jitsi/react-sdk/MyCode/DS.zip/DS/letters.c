c=printf("Enter the character");
scanf("%[^\n]%*c");
printf(c);
