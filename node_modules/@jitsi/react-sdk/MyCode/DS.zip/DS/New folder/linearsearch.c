#include<stdio.h>
int main()
{
	int i,j,n,a[10],key;
	printf("enter the size of the array");
	scanf("%d",&n);
	printf("enter the elements of the array");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter the element to be searched");
	scanf("%d",&key);
	key==a[0];
	for(i=0;i<n;i++)
	{
	  if (a[i]==key)
	  {
	    printf("element found at index %d",a[i]);
	    break;
	  }
	} 
	 if(i==n)
	  {
	    printf("element not found");
	  }	
}
