#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node *head=NULL;
void createStack()
{
	if(head==NULL)
	{
		int n,i;
		printf("enter the number of nodes:");
		scanf("%d",&n);
		if(n!=0)
		{
			int data;
			struct node *newnode;
			printf("\n Enter the data to be inputed into the stack:\n");
			scanf("%d",&data);
			head=malloc(sizeof(newnode));
			head->data=data;
			head->next=NULL;
			for(i=2;i<=n;i++)
			{
				newnode=malloc(sizeof(struct node));
				scanf("%d",&data);
				newnode->data=data;
				newnode->next=head;
				head=newnode;
			}
			printf("\n The Stack is created\n");
		}
	}
	else
	{
		printf("\n The Stack is already created\n");
	}
}
void traverse()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n The Stack id empty\n");
	}
	else
	{
		temp=head;
		while(temp!=NULL)
		{
			printf("%d",temp->data);
			temp=temp->next;
		}
	}
	printf("\n");
}
void push(int v)
{
	struct node *newnode;
	newnode=malloc(sizeof(struct node));
	newnode->data=v;
	newnode->next=head;
	head=newnode;
}
void pop()
{
	struct node *temp;
	if(head==NULL)
	{
		printf("\n The Stack is empty\n");
	}
	else
	{
		printf("popped element is %d\n",head->data);
		temp=head;
		head=head->next;
		free(temp);
	}
}
int main()
{
	int ch;
	while(1)
	{
		printf("****MENU****\n");
		printf("1.To input element into the stack\n");
		printf("2.To see the stack\n");
		printf("3.To push\n");
		printf("4.to pop\n");
		printf("5.Exit \n");
	printf("Enter your choice");
		scanf("%d",&ch);
	switch(ch)
	{
		case 1:
		{
			createStack();
			break;
		}
		case 2:
		{
			traverse();
		break;
		}
		case 3:
		{
			int v;
			printf("\n Enter the element to be pushed:");
			scanf("%d",&v);
			push(v);
			break;
		}
		case 4:
		{
			pop();
			break;
		}
		case 5:
		{
			exit(0);
		}
		default:
		{
			printf("WRONG CHOICE");
		}
	}
}
}


