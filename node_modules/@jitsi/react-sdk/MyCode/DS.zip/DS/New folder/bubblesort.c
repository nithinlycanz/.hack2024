#include<stdio.h>
include<conio.h>
void main()
{
	int i,j,n,a[10];
	printf("enter the size of the array");
	scanf("%d",&n);
	printf("enter the elements of the array");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	 	printf("%d",a[i]);
	for(j=i+1;j<n;j++)
	if a[i]>a[j]
	{
		t=a[i];
		a[i]=a[j];
		a[i]=t;
	}
	printf("the sorted elements are : /n",);
	scanf("%d",&a[i]);
}
