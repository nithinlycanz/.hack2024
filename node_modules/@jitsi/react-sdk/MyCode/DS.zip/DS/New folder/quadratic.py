#program to find the factors of a quadratic equation
import math
a=int(input("enter the coefficient of x^2"))
b=int(input("enter the coefficient of x"))
c=int(input("enter the constant"))
d=float(b*b-4*a*c)
if d>0:
	x1=float((-b+math.sqrt(d)/2*a))
	x2=float((-b-math.sqrt(d)/2*a))
	print("factors= ",x1,x2)
else:
	if d==0:
		x3=(-b/2)
		print("the equation has only one root= ",x3)
	else:
		print("imaginary roots")
