I#include<stdio.h>
void  main()
{
	int n,a[n],i,list[n];
	printf("enter the size of list");
	scanf("%d",&n);
	printf("enter the list elements");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
{
	temp=ptr;
	ptr=ptr*link;
	ptr
	i=i-1;
	while(ptr!=NULL&&I<=N)
	
