#include<stdio.h>
void selectionsort(int a[],int n);
int main()
{
	int i,j,count,t,n[20];
	printf("how many number you are going to enter");
	scanf("%d",&count);
	printf("enter %d elements",count);
	for(i=0;i<count;i++)
	{
		scanf("%d",&n[i]);
	}
	for(i=0;i<count;i++)
	{
	  for(j=i+1;j<count;j++)
	  {
	  	if(n[i]>n[j])
	  	{
	  		t=n[i];
	  		n[i]=n[j];
	  		n[j]=t;
	  	}
	  }
	}
	printf("sorted element");
	for(i=0;i<count;i++)
	{
		printf("%d",n[i]);
	}
}
	 
	
	
