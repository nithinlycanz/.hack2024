#include<stdio.h>
int main()
{
	int a[10],i,n,first,middle,last,search;
	printf("enter the size of the array");
	scanf("%d",&n);
	printf("enter the elements of the array");
	for(i=0;i<n;i++)
	{
	  scanf("%d",&a[i]);
	}
	printf("enter the value to find ");
	scanf("%d",&search);
	first=0;
	last=search-1;
	middle=(first+last)/2;
	while(first<=last)
	{
	    if(a[middle]<search)
	    {
	    	first=middle+1;
	    }
	    if(a[middle]==search)
	     {
	    	printf("%d found at index %d/n",search,middle+1);
	    	break;
	     }
	    else
	    {
	      last=middle-1;
	      middle=(first+last)/2;
	    }
       }
	if(first>last)
	{
	    	printf(" %d is not found ",search);
	    	return 0;  	
	
	}

}	    	
