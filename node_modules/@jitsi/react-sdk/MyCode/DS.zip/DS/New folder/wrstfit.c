#include <stdio.h>

void WorstFit(int blockSize[], int m, int processSize[], int n);
void main()

{
	int blockSize[50],processSize[50],i, j,n,m,indexPlaced;
	int allocation[n];
	printf("WORST FIT");
	printf("enter the no of blocks:\n");
	scanf("%d",&m);
	printf("enter the no of processes:\n");
	scanf("%d",&n);
	for(i=0;i<m;i++)
	{
		printf("enter the blocksize of block %d:",i+1);
		scanf("%d",&blockSize[i]);
	}
	printf("enter the process size:");
	for(i=0;i<n;i++)
		scanf("%d",&processSize[i]);
  	  for(int i = 0; i < n; i++){
  	      allocation[i] = -1;
  	  } 
  	  for (int i=0; i < n; i++)
  	  {
		int indexPlaced = -1;
		for(int j = 0; j < m; j++)
		{
		    if(blockSize[j] >= processSize[i])
           	 {
             	  if (indexPlaced == -1)
             	       indexPlaced = j;
                else if (blockSize[indexPlaced] < blockSize[j])
                 	   indexPlaced = j;
           	 }
        }
        if (indexPlaced != -1)
        {
            allocation[i] = indexPlaced;
            blockSize[indexPlaced] -= processSize[i];
        }
    }
    printf("\nProcess No.\tProcess Size\tBlock no.\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d \t\t\t %d \t\t\t", i+1, processSize[i]);
        if (allocation[i] != -1)
            printf("%d\n",allocation[i] + 1);
        else
            printf("Not Allocated\n");
    }
}
