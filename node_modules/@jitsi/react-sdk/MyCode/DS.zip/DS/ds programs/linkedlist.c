#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node*link;
};

struct node*start=NULL;
void createList()
{
    if(start==NULL){
        int n;
        printf("\n enter the number of nodes");
        scanf("%d",&n);
        if(n!=0){
            int data;
            struct node*newnode;struct node*temp;
            newnode-malloc(sizeof(struct node));
            start=newnode;
            temp=start;
            printf("\n enter no to be inserted:");
            scanf("%d",&data);
            start->info=data;
            for (i=z;i<=n;i++){
                newnode=malloc(sizeof(struct node));
                temp->link=newnode;
                printf("\n enter the no to be inserted:");
                scanf("%d",&data);
                newnode->info=data;
                temp=temp->link;
                
            }printf("\n the list is created")
        }
        else{
        printf("\n the list is already created \n");
        }
    void traverse()
    {
        struct node*temp
       if(start==NULL);
        printf("\nlist is empty\n");
       else 
            temp=start;
            while (temp!=NULL)
            {
                printf("data=%d\n",temp->info);
                temp=temp->list;
            }
    }
    }
}
    void insertAtFront(){
        int data;
        struct node*temp;
        temp=malloc(sizeof(struct node));
        printf("\n enter no to be inserted:");
        scanf("%d",&data);
        temp->info=data;
        temp->link=start:
        start=temp;
        
    }
    void insertAtEnd(){
        int data;
        struct node*temp,*head;
        temp=malloc(sizeof(struct node));
        printf("\n enter the no to be inserted")
        {
            /* data */
        };
        

    }
    
            
            
            