#include<stdio.h>
void firstFit(int blockSize[], int m, int processSize[], int n);

void main()

{
	int blockSize[50],processSize[50],i, j,n,m;
	int allocation[n];
	printf("enter the no of blocks:\n");
	scanf("%d",&m);
	printf("enter the no of processes:\n");
	scanf("%d",&n);
	for(i=0;i<m;i++)
	{
		printf("enter the blocksize of block %d:",i+1);
		scanf("%d",&blockSize[i]);
	}
	printf("enter the process size:");
	for(i=0;i<n;i++)
		scanf("%d",&processSize[i]);
	for(i = 0; i < n; i++)
	{
		allocation[i] = -1;
	}
	for (i = 0; i < n; i++)	
	{
		for (j = 0; j < m; j++)	 
		{
			if (blockSize[j] >= processSize[i])
			{
				allocation[i] = j;
				blockSize[j] -= processSize[i];
				break;
			}
		}
	}
	printf("\nProcess No.\tProcess Size\tBlock no.\n");
	for (i = 0; i < n; i++)
	{
		printf(" %d\t\t\t", i+1);
		printf("%d\t\t\t\t", processSize[i]);
		if (allocation[i] != -1)
			printf("%d", allocation[i] + 1);
		else
			printf("Not Allocated");
		printf("\n");
	}
}
