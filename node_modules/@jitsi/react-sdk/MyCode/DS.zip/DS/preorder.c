#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*left;
	struct node*right;
}*root=NULL,*temp=NULL;
void inserttoBST(struct node*);
void inorder(struct node*);
void preorder(struct node*);
void postorder(struct node*);
int main()
{
	int x,choice;
	printf("\n 1.insert 2.traversal 3.exit\t");
	do{
		printf("\nenter choice:\n");
		scanf("%d",&choice);
		switch(choice){
		case 1:
			printf("enter the value to be inserted:");
			scanf("%d",&x);
			temp=(struct node*)malloc(sizeof(struct node));
			temp->data=x;
			temp->left=temp->right=NULL;
			inserttoBST(root);
		break;
		case 2:
			printf("\ninorder");
			inorder(root);
			printf("\npreorder");
			preorder(root);
			printf("\npostorder");
			postorder(root);
		break;
		case 3:printf("EXITING...");
		exit(0);
		break;
		default:
			printf("wrong choice");
		}
		}
		while(choice!=5);
		return 1;
		}
void inserttoBST(struct node*atnode)
{
if(root==NULL){
root=temp;
return;
}
if(temp->data<atnode->data){
if(atnode->left==NULL){
atnode->left=temp;
}else{
inserttoBST(atnode->left);
}
}else{
if(atnode->right==NULL){
atnode->right=temp;
}else{
inserttoBST(atnode->right);
}
}
}
void inorder(struct node*atnode)
{
if(atnode!=NULL){
	inorder(atnode->left);
	printf("\t%d",atnode->data);
	inorder(atnode->right);
}
}
void preorder(struct node*atnode)
{
if(atnode!=NULL){
	printf("\t%d",atnode->data);
	preorder(atnode->left);
	preorder(atnode->right);
}
}
void postorder(struct node*atnode)
{
if(atnode!=NULL){
	postorder(atnode->left);
	postorder(atnode->right);
	printf("\t%d",atnode->data);
	
}
}

	

