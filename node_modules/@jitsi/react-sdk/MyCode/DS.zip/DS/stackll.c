#include<stdio.h>
#include<stdlib.h>

struct Node
{
   int data;
   struct Node *next;
}*top = NULL;

void push(int);
void pop();
void display();
int peek();
void main()
{
   int choice, value;

   printf("\nStack using Linked List\n");
   printf("\nselect operation\n");
      printf("1. Push\n2. Pop\n3. peek\n4. display\n5. exit\n");
   while(1){
      
      printf("\nEnter your choice: ");
      scanf("%d",&choice);
      switch(choice){
	 case 1: printf("Enter the value to be inserted: ");
		 scanf("%d", &value);
		 push(value);
		 break;
	 case 2: pop(); break;
	 case 3: peek(); break;
	 case 4: display(); break;
	 case 5: exit(0);
	 default: printf("\nWrong selection! Please try again!\n");
      }
   }
}
void push(int value)
{
   struct Node *newNode;
   newNode = (struct Node*)malloc(sizeof(struct Node));
   newNode->data = value;
   if(top == NULL)
      newNode->next = NULL;
   else
      newNode->next = top;
   top = newNode;
   printf("\nInsertion  Success!\n");
   display();
}
void pop()
{
   if(top == NULL)
      printf("\nStack is Empty!!!\n");
   else{
      struct Node *temp = top;
      printf("\nDeleted element: %d", temp->data);
      top = temp->next;
      free(temp);
   }
   display();
}
int peek(){
	printf("top most element is %d\n",top->data);
	}
void display()
{
   if(top == NULL)
      printf("\nStack is Empty!\n");
   else{
      struct Node *temp = top;
            	printf("stack elements are:");
      while(temp->next != NULL){

	 printf("%d\t",temp->data);
	 temp = temp -> next;
      }
      printf("\t%d",temp->data);
   }
}
