package com.example.myactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.opengl.ETC1;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView NAME = findViewById(R.id.NAME);
    EditText DAYNIGH = findViewById(R.id.searchCITY);
    Button SEARCH = findViewById(R.id.SEARCH);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

